from syjson.classes import SyJson
