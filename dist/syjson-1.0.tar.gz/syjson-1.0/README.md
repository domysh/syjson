# syjson
A library for manage json file as variable good for updated and small json file such as settings file
